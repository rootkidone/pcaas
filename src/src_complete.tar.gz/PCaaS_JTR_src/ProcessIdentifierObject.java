/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rootkid
 */
public class ProcessIdentifierObject {
    
    private Integer _processID;
    private ProcessControl _runningProcess;
    private final String _pluginIdentifier = "John the Ripper";
    
    public ProcessIdentifierObject(Integer processID, ProcessControl p){
        this._processID = processID;
        this._runningProcess = p;
    }
    
    public Integer getProcessID(){return _processID;}
    public ProcessControl getProcess(){return _runningProcess;}
    
    public boolean equals(ProcessIdentifierObject other){
        if(this._processID.equals(other._processID)){
            return true;
        }
        if(this._runningProcess.equals(other.getProcess())){
            return true;
        }
        return false;
    }
    public String toString(){
        return _processID + ":" + _pluginIdentifier;
    }
    
}
