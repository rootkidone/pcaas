/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author rootkid
 */
public class ProcessManager {
    
    private List<ProcessIdentifierObject> _processList = 
            new ArrayList<ProcessIdentifierObject>();
    private Integer _IDCounter = 1000;
    
    public ProcessManager(){}
    
    public List<String> getRunnningProcessesFormatted(){
        List<String> resultStrings = new ArrayList<String>();
        for(ProcessIdentifierObject po : _processList){
            resultStrings.add(po.toString());
        }
        return resultStrings;
    }
    
    public void killAllProcesses(){
        for(ProcessIdentifierObject currObj : _processList){
            currObj.getProcess().getProcess().destroy();
        }
        _processList.clear();
    }
    
    public String getStringFromProcess(ProcessControl pc){
        String resString = "";
        for(ProcessIdentifierObject pIDO : _processList){
            if(pIDO.getProcess().equals(pc)){
                System.out.println(pIDO.toString() +"   "+ pc.toString());
                resString = pIDO.toString();
            }
        }
        return resString;
    }
    
    public List<ProcessIdentifierObject> getProcessList(){
        return _processList;
    }
    
    public void addProcessToList(ProcessControl p){
        _IDCounter = _IDCounter+1;
        ProcessIdentifierObject pO = new ProcessIdentifierObject(_IDCounter, p); 
        synchronized(_processList){
        _processList.add(pO);
        }
        
    }
    
    
    public void deleteProcessFromList(ProcessControl p){
        synchronized (_processList) {
            for(Iterator<ProcessIdentifierObject> it = _processList.iterator();
                    it.hasNext();){
                ProcessIdentifierObject currObj = it.next();
                if(currObj.getProcess().equals(p.getProcess())){
                    it.remove();
                }
            }
        }
    }
    
}
