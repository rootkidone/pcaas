

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.List;

import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.ShutdownSignalException;

//ProcessControl managed des Arbeitsauftrag des Frameworks,
//der Output des Prozesses wird durch den PluginMessSender an das
//Framework zurück gesendet.

public class ProcessControl implements Runnable {
	
	private String _jtRArguments;
	private String _directory;
	private int _interval;
	private PluginMessSender _plugMessSender;
        private boolean _cafFlag;
        private Process _process;
        private ProcessMonitor _processMonitor;
        private ProcessManager _processManager;
	//private PlugInMessReceiver _plugMessReceiver = new PlugInMessReceiver();
	
	//jtRArguments = Arbeitsauftrag
	public ProcessControl(String jtRArguments, String directory, int interval,
                PluginMessSender pluginSender, boolean cafFlag, ProcessManager pm){
		this._jtRArguments = jtRArguments;
		this._directory = directory;
		this._interval = interval;
                this._plugMessSender = pluginSender;
                this._cafFlag = cafFlag;
                this._processManager = pm;
		//receiver not needed here
	}
	
	public static ProcessControl create(String jtRArguments, String directory, int interval,
                PluginMessSender pluginSender, boolean cafFlag, ProcessManager pm){
		ProcessControl p = new ProcessControl(jtRArguments, directory, interval,
                pluginSender, cafFlag, pm);
		Thread t = new Thread(p);
		t.start();
		return p;
	}
        
        public boolean equals(ProcessControl pc){
            //HIER FEHLER AUF JEDEN FALL, OBJEKT WIRD NICHT GEFUNDEN; STRING IST LEER
            
            if(this._process == (pc._process)){
                return true;
            }
            return false;
        }
        
        public Process getProcess(){return _process;}
        public ProcessMonitor getMonitor(){return _processMonitor;}

	@Override
	public void run() {
		// TODO Auto-generated method stub

			//CommandListe bauen
			String text = _jtRArguments;
			String[] formattedText = text.split(" ");

			//Automatisierung zu Testzwecken
			//String[] commands = { "john", "--wordlist=password.lst", "mypasswd"};// komma?

			//commandos übergeben, Dir setzen, Proc starten
			ProcessBuilder proB = new ProcessBuilder(formattedText);
			proB.directory(new File(_directory));
			proB.redirectErrorStream(true);
			
			//PluginMessSender plugMess = new PluginMessSender();
			
			Process process;
			try {
				process = proB.start();
                                _process = process;
				//Terminierungsüberwachung des Proc
				ProcessMonitor proM = ProcessMonitor.create(process);
                                _processMonitor = proM;
				//StatusAbfrage
				ProcessWriterAsync.create(proM, process, 
                                        _plugMessSender, _directory, _interval,
                                        _cafFlag);

				//schreibend
				OutputStream os = process.getOutputStream();
				OutputStreamWriter osw = new OutputStreamWriter(os);
				BufferedWriter bw = new BufferedWriter(osw);

				//lesend
				InputStream is = process.getInputStream();
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);
				
				String line;
				System.out.printf("Output of running %s is:\n",
						Arrays.toString(formattedText));
				
				//Proc output
				while ((line = br.readLine()) != null 
                                        ) {
					//System.out.println(line + "##");
					//geht zurück an das Framework
					_plugMessSender.sendMessage("Hashcat", line, _cafFlag);
				}
                                this._plugMessSender.sendMessageWithComment("Process Management", 
                                        "DELETEPROCESS", false, _processManager.getStringFromProcess(this));
                                _processManager.deleteProcessFromList(this);
				bw.close();
                                
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
                                System.out.println("Exception in ProcessConrol, Stream is closed due to killed Process, keep moving:D");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}
