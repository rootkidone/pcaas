/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Adapter;

import Framework.FrameProcessIdentifierObject;
import Framework.FrameworkController;
import Framework.PasswdDataType;
import Framework.algorithm.PasswdAlgorithmDataType;
import Framework.hashtag.HashTagDataType;
import GUI.FrameworkGUI;
import PublicClasses.CommandObject;
import PublicClasses.PluginObject;
import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author rootkid
 */
public class GUIFrameworkAdapter {

    private FrameworkGUI _gui;
    private FrameworkController _frameworkController;

    public GUIFrameworkAdapter() throws IOException {
        _frameworkController = new FrameworkController(this);
    }

    public void setGUI(FrameworkGUI gui) {
        _gui = gui;
    }
    
    public Set<PasswdAlgorithmDataType> getAlgorithmList(){
        return _frameworkController.getAlgorithmList();
    }
    
    public Set<HashTagDataType> readPasswordFileAndReturnHashTags(File file) throws IOException, 
            NoSuchAlgorithmException, InterruptedException, IllegalAccessException{
        Set<HashTagDataType> resSet = _frameworkController.readPasswordFileAndReturnHashTags(file);
        return resSet;
    }
    
    public void convertFileWithSalt(File file, String algorithm)throws IOException, NoSuchAlgorithmException, 
            InterruptedException, IllegalAccessException{
        _frameworkController.convertFileWithSalt(file, algorithm);
    }
    
    public void convertFile(File file, String algorithm)throws IOException, NoSuchAlgorithmException, 
            InterruptedException, IllegalAccessException{
        _frameworkController.convertFile(file, algorithm);
    }

    public void clearProcessList(){
        _frameworkController.clearProcessList();
    }
    
    public void setFrameworkController(FrameworkController controller) {
        _frameworkController = controller;
    }
    
    public void buildAndSendCAFCommand(String mode, String name, HashMap<String, String> info,
        Integer hashType, String passwordList, String wordList, String directory) throws IOException, NoSuchAlgorithmException, InterruptedException, IllegalAccessException{
        _frameworkController.buildAndSendCAFCommand(mode, name, info, hashType, 
                passwordList, wordList, directory);
    }

    public void sendMessage(CommandObject message) {
        _frameworkController.sendMessage(message);
    }
    
    public List<FrameProcessIdentifierObject> getProcessMap(){
        return _frameworkController.getProcessMap();
    }
    
    public List<PluginObject> getRegisteredPlugins(){
        return _frameworkController.getRegisteredPlugins();
    }
    
    public void showMessageInGUI(String message, String plugin){
        _gui.showMessage(message, plugin);
    }
    
    
}
