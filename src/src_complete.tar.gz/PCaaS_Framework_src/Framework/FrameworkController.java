package Framework;

import Adapter.GUIFrameworkAdapter;
import Framework.algorithm.PasswdAlgorithmDataType;
import Framework.hashtag.HashTagDataType;
import PublicClasses.CommandObject;
import PublicClasses.PluginObject;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FrameworkController {

    private FrameMessSender _frameSender;
    private FrameMessReceiver _frameReceiver;
    private FramePluginManager _pluginManager;
    private GUIFrameworkAdapter _adapter;
    private FrameProcessManager _processManager = new FrameProcessManager();
    private PasswdManager _passwdManager;

    public FrameworkController(GUIFrameworkAdapter adapter) throws IOException {
        this._frameSender = new FrameMessSender();
        this._frameReceiver = new FrameMessReceiver(this);
        this._pluginManager = new FramePluginManager();
        this._passwdManager = new PasswdManager();
        this._adapter = adapter;
        run();
    }

    public Set<HashTagDataType> readPasswordFileAndReturnHashTags(File file) throws IOException,
            NoSuchAlgorithmException, InterruptedException, IllegalAccessException {
        _passwdManager = new PasswdManager();
        _passwdManager.readPasswordFile(file);
        Set<HashTagDataType> resultSet = _passwdManager.getHashTagManager().getHashTagDataTypes();
        return resultSet;
    }

    public Set<PasswdAlgorithmDataType> getAlgorithmList() {
        return _passwdManager.getPasswdAlgorithmManager().getAlgorithmList();
    }

    public void convertFile(File file, String algorithm) throws IOException, NoSuchAlgorithmException,
            InterruptedException, IllegalAccessException {
        //_passwdManager.buildPasswordFile(null, null, "", false);..
        String[] algorithmLabelAndTag = algorithm.split("/");
        PasswdAlgorithmDataType pADT = new PasswdAlgorithmDataType(algorithmLabelAndTag[1],
                algorithmLabelAndTag[0]);
        //muss neu belegt werden um die Überschreibung alterer dateien nicht zu gefährden
        //auch doppelte accounts aus verschiedenen Dateien können sonst aufgrund der 
        //Datenverwaltung zu falschen Ergebnissen führen
        _passwdManager = new PasswdManager();
        _passwdManager.buildPasswordFile(file, pADT, "", false);
    }

    public void convertFileWithSalt(File file, String algorithm) throws IOException, NoSuchAlgorithmException,
            InterruptedException, IllegalAccessException {
        //_passwdManager.buildPasswordFile(null, null, "", true);..
        String[] algorithmLabelAndTag = algorithm.split("/");
        PasswdAlgorithmDataType pADT = new PasswdAlgorithmDataType(algorithmLabelAndTag[1],
                algorithmLabelAndTag[0]);
        //muss neu belegt werden um die Überschreibung alterer dateien nicht zu gefähren
        //auch doppelte accounts aus verschiedenen Dateien können sonst aufgrund der 
        //Datenverwaltung zu falschen Ergebnissen führen
        _passwdManager = new PasswdManager();
        _passwdManager.buildPasswordFile(file, pADT, "", true);
    }

    public void deleteProcessFromManager(Integer id, String instance) {
        _processManager.deleteProcessFromMap(id, instance);
    }

    public void clearProcessList() {
        _processManager.clearProcessMap();
    }

    public void addProcessToManager(Integer id, String instance) {
        _processManager.addProcessToMap(id, instance);
    }

    public List<FrameProcessIdentifierObject> getProcessMap() {
        List<FrameProcessIdentifierObject> resList = _processManager.getProcessList();
        //_processMap.clearProcessMap();
        return resList;
    }

    public void run() {
        //new Thread(_frameSender).start();
        new Thread(_frameReceiver).start();
    }

    public String writePasswordAsChars(String passwd) {
        String resString = "";
        for (int i = 0; i < (passwd.length()); i += 2) {
            char res = (char) Integer.parseInt(passwd.substring(i, i + 1));
            resString = resString + res;
        }
        return resString;
    }

    private void buildHashcatPWFileFromMode(Integer hashType, File hashcatFile,
            String passwordList) throws IOException, FileNotFoundException, NoSuchAlgorithmException, IllegalAccessException, InterruptedException {

        _passwdManager = new PasswdManager();
        try {
            List<PasswdDataType> passwdDataTypeList
                    = _passwdManager.readPasswordFileAndReturnPasswdDataTypeList(new File(passwordList));
            for (PasswdDataType data : passwdDataTypeList) {
                try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(hashcatFile, true)))) {
                    System.out.println("HASHTYPE: " + hashType);
                    switch (hashType) {
                        case 0:
                            out.println(data.getPassword().getPassword().replace("$", ""));
                            break;
                        case 10:
                            out.println(data.getPassword().getPassword().replace("$", "")
                                    + ":" + data.getPassword().getSalt().replace("$", ""));
                            break;
                        case 100:
                            out.println(data.getPassword().getPassword().replace("$", ""));
                            break;
                        case 110:
                            out.println(data.getPassword().getPassword().replace("$", "")
                                    + ":" + data.getPassword().getSalt().replace("$", ""));
                            break;
                        case 200:
                            out.println(data.getPassword().getPassword().replace("$", ""));
                            break;
                        case 500:
                            out.println(data.getPassword().getHash());
                            break;
                        case 1400:
                            out.println(data.getPassword().getPassword().replace("$", ""));
                            break;
                        case 1410:
                            out.println(data.getPassword().getPassword().replace("$", "")
                                    + ":" + data.getPassword().getSalt().replace("$", ""));
                            break;
                        case 1700:
                            out.println(data.getPassword().getPassword().replace("$", ""));
                            break;
                        case 1710:
                            out.println(data.getPassword().getPassword().replace("$", "")
                                    + ":" + data.getPassword().getSalt().replace("$", ""));
                            break;
                        case 1800:
                            out.println(data.getPassword().getHash());
                            break;
                        case 9999:
                            out.println(data.getPassword().getPassword().replace("$", ""));
                            break;
                        default:
                            out.println(data.getPassword().getHash());
                            break;

                    }
                } catch (IOException e) {

                }
            }

            //System.out.println(passwordList + "KKKKKKKKKK");
        } catch (IllegalArgumentException ex) {

        }
    }

    public void buildAndSendCAFCommand(String mode, String name, HashMap<String, String> info,
            Integer hashType, String passwordList, String wordList, String directory) throws IOException, NoSuchAlgorithmException, InterruptedException, IllegalAccessException {
        PluginObject pluginToSend = _pluginManager.getPluginFromName(name);

        if (pluginToSend != null) {
            if (name.equals("Hashcat")) {
                File hashcatFile = new File(passwordList + ".hashcat");
                PrintWriter writer = new PrintWriter(hashcatFile);
                writer.print("");
                writer.close();
                buildHashcatPWFileFromMode(hashType, hashcatFile, passwordList);
                passwordList = hashcatFile.getAbsolutePath();

            }

            String command = buildCommandStringForCAF(pluginToSend, mode, hashType, wordList,
                    passwordList);

            CommandObject commandObj = new CommandObject(name,
                    directory, command, true, true,
                    "saveOutputTo", "saveStatTo", 5);
            commandObj.setCAFFLag(true);
            sendMessage(commandObj);
        }
    }

    private String buildCommandStringForCAF(PluginObject po, String mode,
            Integer hashType, String wordList, String passwordList) {
        String resultCommand = "";
        if (mode.equals("BruteForce")) {
            String bruteForceComm = po.getBruteForceCommand();
            //replace Keywords
            String hashTypeReplaced = bruteForceComm.replace("HASHT", hashType.toString());
            String wordListReplaced = hashTypeReplaced.replace("WORDL", wordList);
            resultCommand = wordListReplaced.replace("PASSD", passwordList);

        } else if (mode.equals("WordList")) {
            String wordListCommand = po.getWordListCommandName();
            //replace Keywords
            String hashTypeReplaced = wordListCommand.replace("HASHT", hashType.toString());
            String wordListReplaced = hashTypeReplaced.replace("WORDL", wordList);
            resultCommand = wordListReplaced.replace("PASSD", passwordList);
        } else {
        }
        return resultCommand;
    }

    public void sendMessage(CommandObject message) {
        _frameSender.sendMessage(message);
    }

    public void addPluginToManager(PluginObject po) {
        _pluginManager.addToList(po);
    }

    public List<PluginObject> getRegisteredPlugins() {
        return _pluginManager.getRegisteredPlugins();
    }

    public void showMessageInGUI(String message, String plugin) {
        _adapter.showMessageInGUI(message, plugin);
    }

}
