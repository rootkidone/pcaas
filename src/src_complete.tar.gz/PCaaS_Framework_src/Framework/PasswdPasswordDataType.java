package Framework;


import Framework.algorithm.PasswdAlgorithmDataType;
import Framework.crypt.JCrypt;
import Framework.hashtag.HashTagDataType;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

/**
 * 
 * <p/>
 * Reference:
 * - http://man7.org/linux/man-pages/man3/passwd.crypt.3.html
 */
public class PasswdPasswordDataType {

    // hex characters
    private static final String HEXES = "0123456789ABCDEF";
    // salt is a two-character string chosen from the set [a-zA-Z0-9./].
    private static final int SALT_LENGTH = 2;
    private static final String SALT_CHARACTER = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890./";
    /**
     * Represents a password with his three components and some helper variables.
     * <p/>
     * Syntax: $Algorithm$Salt$Password+Salt
     * 1. Algorithm
     * 2. Salt
     * 3. Password + Salt
     * (Saved with the leading $)
     * <p/>
     * - Password in plaintext
     * - List of possible hashes
     */
    private PasswdAlgorithmDataType algorithm;
    private String salt;
    private String password;
    private String plaintextPassword;
    private List<HashTagDataType> hashTag;

    /**
     * Constructor.
     */
    public PasswdPasswordDataType(PasswdAlgorithmDataType algorithm, String salt, String password, boolean plaintextPassword, boolean enableSalt) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        this.algorithm = algorithm;

        if (!plaintextPassword) {
            this.salt = "$" + salt;
            this.password = "$" + password;
        } else {
            // Salt and Password
            if (enableSalt) {
                if (!salt.isEmpty()) {
                    this.salt = "$" + salt;
                    this.password = "$" + generatePassword(algorithm, password + salt);
                } else {
                    String generatedSalt = generateSalt();
                    this.salt = "$" + generatedSalt;
                    this.password = "$" + generatePassword(algorithm, password + generatedSalt);
                }
            } else {
                this.salt = "$" + salt;
                this.password = "$" + generatePassword(algorithm, password);
            }
        }

        this.plaintextPassword = password;
    }

    /**
     * @param raw
     * @return
     */
    public static String getHex(byte[] raw) {
        if (raw == null) {
            return null;
        }
        final StringBuilder hex = new StringBuilder(2 * raw.length);
        for (final byte b : raw) {
            hex.append(HEXES.charAt((b & 0xF0) >> 4))
                    .append(HEXES.charAt((b & 0x0F)));
        }
        return hex.toString();
    }

    /**
     * http://howtodoinjava.com/2013/07/22/how-to-generate-secure-password-hash-md5-sha-pbkdf2-bcrypt-examples/
     *
     * @param algorithm
     * @param password
     * @return
     */
    private String generatePassword(PasswdAlgorithmDataType algorithm, String password) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        String generatedPassword = null;

        // Create MessageDigest instance for MD5
        MessageDigest md = MessageDigest.getInstance(algorithm.getLabel());

            /* Add password bytes to digest */
        md.update(password.getBytes("UTF-8"));

        // Get the hash's bytes
        byte[] bytes = md.digest();

        // This bytes[] has bytes in decimal format;
        // Convert it to hexadecimal format
        StringBuilder sb = new StringBuilder();
        for (byte aByte : bytes) {
            sb.append(Integer.toString((aByte & 0xff) + 0x100, 16).substring(1));
        }

        // Get complete hashed password in hex format
        generatedPassword = sb.toString();

        return generatedPassword;
    }

    /**
     * Generating a random salt with JCrypt (Unix).
     *
     * @return String salt
     */
    private String generateSalt() {
        String[] salt = {"", ""};
        int charactersLength = SALT_CHARACTER.length();

        for (int i = 0; i < SALT_LENGTH; i++) {
            double index = Math.random() * charactersLength;
            salt[i] = String.valueOf(SALT_CHARACTER.charAt((int) index));
        }

        return JCrypt.crypt(salt[0], salt[1]);
    }

    /**
     * Setter.
     */
    public void setHashTag(List<HashTagDataType> hashTag) {
        this.hashTag = hashTag;
    }

    /**
     * Getter.
     */
    public PasswdAlgorithmDataType getAlgorithm() {
        return algorithm;
    }

    public String getSalt() {
        return salt;
    }

    public String getPassword() {
        return password;
    }

    public String getPlaintextPassword() {
        return plaintextPassword;
    }

    public String getHash() {
        return algorithm.getTag() + salt + password;
    }

    public List<HashTagDataType> getHashTagList() {
        return hashTag;
    }

}
