package Framework;


import Framework.algorithm.PasswdAlgorithmDataType;
import Framework.algorithm.PasswdAlgorithmManager;
import Framework.hashtag.HashTagManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;


public class PasswdManager {

    /**
     * Represents a manager which handling the full list of user, algorithm and hashtag entries.
     */
    private List<PasswdDataType> passwdList;
    private PasswdAlgorithmManager passwdAlgorithmManager;
    private HashTagManager hashTagManager;

    /**
     * Constructor.
     */
    public PasswdManager() throws IOException {
        passwdList = new ArrayList<PasswdDataType>();
        passwdAlgorithmManager = new PasswdAlgorithmManager();
        hashTagManager = new HashTagManager();
    }
    
    public List<PasswdDataType> getAlgorithmList(){
        return passwdList;
    }

    /**
     * @param fromThisFile
     * @param algorithmDataType
     * @param salt
     */
    public void buildPasswordFile(File fromThisFile, 
            PasswdAlgorithmDataType algorithmDataType, String salt, 
            boolean enableSalt) throws IOException, NoSuchAlgorithmException, InterruptedException, IllegalAccessException {
        passwdList = new PasswdReader(fromThisFile, passwdAlgorithmManager, hashTagManager).readSimpleFile(algorithmDataType, salt, enableSalt);
        new PasswdWriter(new File(fromThisFile.getAbsoluteFile().toString() + ".out")).write(passwdList);
    }

    public void buildPasswordFile(File fromThisFile, PasswdAlgorithmDataType algorithmDataType) throws IOException, NoSuchAlgorithmException, IllegalAccessException, InterruptedException {
        buildPasswordFile(fromThisFile, algorithmDataType, "", true);
    }

    public void buildPasswordFile(File fromThisFile) throws IOException, NoSuchAlgorithmException, IllegalAccessException, InterruptedException {
        buildPasswordFile(fromThisFile, passwdAlgorithmManager.getAlgorithmByLabel("SHA-256"), "", true);
    }

    /**
     * @param file
     */
    public void readPasswordFile(File file) throws IOException, NoSuchAlgorithmException, InterruptedException, IllegalAccessException {
        if (!passwdList.isEmpty()) {
            passwdList.clear();
        }

        passwdList = new PasswdReader(file, passwdAlgorithmManager, hashTagManager).readCustomFile(false, false);
    }
    
    public List<PasswdDataType> readPasswordFileAndReturnPasswdDataTypeList(File file) throws FileNotFoundException, NoSuchAlgorithmException, IOException, IllegalAccessException, InterruptedException{
        if (!passwdList.isEmpty()) {
            passwdList.clear();
        }

        passwdList = new PasswdReader(file, passwdAlgorithmManager, hashTagManager).readCustomFile(false, false);
        return passwdList;
    }

    /**
     * Getter.
     */
    public HashTagManager getHashTagManager() {
        return hashTagManager;
    }

    public PasswdAlgorithmManager getPasswdAlgorithmManager() {
        return passwdAlgorithmManager;
    }
}
