package Framework;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 * 
 */
public class PasswdWriter {

    /**
     * Represents a file writer which writes a combination of the passwd and shadow file (like "John the Ripper").
     */
    private File file;
    private FileWriter fileWriter;

    /**
     * Constructor.
     */
    public PasswdWriter(File file) throws IOException {
        this.file = file;
        fileWriter = new FileWriter(file);
    }

    /**
     * Writes the combination of passwd and shadow file.
     *
     * @param passwdEntryList
     * @param plaintext
     */
    public void write(List<PasswdDataType> passwdEntryList, boolean plaintext) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        for (PasswdDataType passwd : passwdEntryList) {
            fileWriter.write(passwd.getUser() + ":" +
                            passwd.getPassword().getAlgorithm().getTag() +
                            passwd.getPassword().getSalt() +
                            passwd.getPassword().getPassword() + ":" +
                            passwd.getUid() + ":" +
                            passwd.getGid() + ":" +
                            passwd.getComment() + ":" +
                            passwd.getDir() + ":" +
                            passwd.getShell() + "\n"
            );
        }

        bufferedWriter.close();
    }

    /**
     * Default writer.
     *
     * @param passwdEntryList
     */
    public void write(List<PasswdDataType> passwdEntryList) throws IOException {
        write(passwdEntryList, false);
    }

}
