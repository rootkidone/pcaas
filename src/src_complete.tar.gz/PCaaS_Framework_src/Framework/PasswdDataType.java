package Framework;

/**
 * 
 * <p/>
 * Reference:
 * - http://man7.org/linux/man-pages/man1/passwd.1.html
 */
public class PasswdDataType {

    /**
     * Represents the combination of the passwd and shadow file under linux which can be generated with "John the Ripper".
     * <p/>
     * 1. User
     * 2. Password
     * 3. User ID
     * 4. Group ID
     * 5. Comment
     * 6. Home-Dir
     * 7. Shell
     */
    private String user;
    private PasswdPasswordDataType password;
    private int uid;
    private int gid;
    private String comment;
    private String dir;
    private String shell;

    /**
     * Constructor.
     */
    public PasswdDataType(String user, PasswdPasswordDataType password, int uid, int gid, String comment, String home, String shell) {
        this.user = user;
        this.password = password;
        this.uid = uid;
        this.gid = gid;
        this.comment = comment;
        this.dir = home;
        this.shell = shell;
    }

    /**
     * Getter.
     */
    public String getUser() {
        return user;
    }

    public PasswdPasswordDataType getPassword() {
        return password;
    }

    public int getUid() {
        return uid;
    }

    public int getGid() {
        return gid;
    }

    public String getComment() {
        return comment;
    }

    public String getDir() {
        return dir;
    }

    public String getShell() {
        return shell;
    }

}
