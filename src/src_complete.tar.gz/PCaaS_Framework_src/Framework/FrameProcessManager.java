/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Framework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author rootkid
 */
public class FrameProcessManager {

    private List<FrameProcessIdentifierObject> _processList
            = new ArrayList<FrameProcessIdentifierObject>();

    public FrameProcessManager() {
    }

    public List<FrameProcessIdentifierObject> getProcessList() {
            return _processList;
    }

    public void addProcessToMap(Integer id, String instance) {
        synchronized (_processList) {
            _processList.add(new FrameProcessIdentifierObject(id, instance));
        }
    }

    public void deleteProcessFromMap(Integer id, String instance) {
        synchronized (_processList) {
            for(Iterator<FrameProcessIdentifierObject> it = _processList.iterator();
                    it.hasNext();){
                FrameProcessIdentifierObject currObj = it.next();
                if(currObj.getProcessID().equals(id) && currObj.getProcessInstance().equals(instance)){
                    it.remove();
                }
            }
        }
    }

    public void clearProcessMap() {
        synchronized(_processList){
            _processList.clear();
        }
        
    }

}
