package Framework;


import Framework.algorithm.PasswdAlgorithmDataType;
import Framework.algorithm.PasswdAlgorithmManager;
import Framework.hashtag.HashTagManager;
import java.io.*;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 */
public class PasswdReader {

    /**
     * Represents a reader which can read specifed input files.
     */
    private File file;
    private FileReader fileReader;
    private PasswdAlgorithmManager passwdAlgorithmManager;
    private HashTagManager hashTagManager;

    /**
     * Constructor.
     */
    public PasswdReader(File file, PasswdAlgorithmManager passwdAlgorithmManager, HashTagManager hashTagManager) throws FileNotFoundException {
        this.file = file;
        this.passwdAlgorithmManager = passwdAlgorithmManager;
        this.hashTagManager = hashTagManager;
        this.fileReader = new FileReader(file);
    }

    /**
     * Syntax: user:password
     */
    public List<PasswdDataType> readSimpleFile(PasswdAlgorithmDataType passwdAlgorithmDataType, String salt, boolean enableSalt) throws NoSuchAlgorithmException, IOException, IllegalAccessException, InterruptedException {
        int lineCount = 0;
        int userCount = 1000;
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        List<PasswdDataType> passwdList = new ArrayList<PasswdDataType>();
        String readLine;

        while ((readLine = bufferedReader.readLine()) != null) {
            lineCount++;
            userCount++;
            String[] tokens = readLine.trim().split(":");

            PasswdPasswordDataType dataTypePassword = null;
            if (tokens.length == 2) {
                dataTypePassword = new PasswdPasswordDataType(passwdAlgorithmDataType, salt, tokens[1], true, enableSalt);
            } else {
                throw new IllegalArgumentException(this.getClass().getSimpleName() + ": Line " + lineCount + " unknown line format | " + readLine + " |");
            }

            // count algorithm
            if (passwdAlgorithmDataType != null) {
                passwdAlgorithmDataType.incrementCounter();
            }

            // generate and count hashtag
            if (dataTypePassword != null) {
                dataTypePassword.setHashTag(hashTagManager.getHashTag(dataTypePassword.getHash()));
                passwdList.add(new PasswdDataType(tokens[0], dataTypePassword, userCount, userCount, tokens[0], "/home/" + tokens[0], "/bin/bash"));
            }
        }
        bufferedReader.close();


        return passwdList;
    }

    /**
     * Syntax: etherpad:$MD5$$test:1000:1000:,,#,:/home/etherpad:/bin/bash
     */
    public List<PasswdDataType> readCustomFile(boolean plaintextPassword, boolean enableSalt) throws NoSuchAlgorithmException, IOException, IllegalAccessException, InterruptedException {
        int lineCount = 0;
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        List<PasswdDataType> passwdList = new ArrayList<PasswdDataType>();
        String readLine;

        while ((readLine = bufferedReader.readLine()) != null) {
            lineCount++;
            String[] tokens = readLine.trim().split(":");

            //wurde abgeändert von (tokens.length == 7)
            if (tokens.length == 7) {
                String[] passTokens = tokens[1].split("\\$");

                PasswdAlgorithmDataType passwdAlgorithmDataType = null;
                PasswdPasswordDataType dataTypePassword = null;

                // plaintext password or passwd file
                if (plaintextPassword) {
                    passwdAlgorithmDataType = passwdAlgorithmManager.getAlgorithmByLabel(passTokens[1]);
                    dataTypePassword = new PasswdPasswordDataType(passwdAlgorithmDataType, passTokens[2], passTokens[3], plaintextPassword, enableSalt);
                } else if(passTokens.length >=2){
                    String tag = "$" + passTokens[1];
                    if (passwdAlgorithmManager.algortihmExist(tag)) {
                        passwdAlgorithmDataType = passwdAlgorithmManager.getAlgorithmByTag(tag);
                    } else {
                        passwdAlgorithmManager.addAlgorithm(new PasswdAlgorithmDataType(tag));
                        passwdAlgorithmDataType = passwdAlgorithmManager.getAlgorithmByTag(tag);
                    }
                    dataTypePassword = new PasswdPasswordDataType(passwdAlgorithmDataType, passTokens[2], passTokens[3], plaintextPassword, enableSalt);
                }

                // count algorithm
                if (passwdAlgorithmDataType != null) {
                    passwdAlgorithmDataType.incrementCounter();
                }

                // generate and count hashtag
                //abgeändert von (dataTypePassword != null)
                if (dataTypePassword != null) {
                    dataTypePassword.setHashTag(hashTagManager.getHashTag(dataTypePassword.getHash()));
                    passwdList.add(new PasswdDataType(tokens[0], dataTypePassword, Integer.parseInt(tokens[2]), Integer.parseInt(tokens[3]), tokens[4], tokens[5], tokens[6]));
                }
            } else {
                throw new IllegalArgumentException(this.getClass().getSimpleName() + ": Line " + lineCount + " unknown line format | " + readLine + " |");
            }
        }
        bufferedReader.close();

        return passwdList;
    }

}
