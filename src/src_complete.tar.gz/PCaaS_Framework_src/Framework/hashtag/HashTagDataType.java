package Framework.hashtag;

/**
 * 
 * <p/>
 * Reference:
 * - http://www.smeegesec.com/2013/11/hashtag-password-hash-identification.html
 */
public class HashTagDataType {

    /**
     * Represents a hashtag. A hashtag have a name and possible have a mode for the hashcat tool.
     * There is counter to count the usage of a hashtag in the loaded file.
     */
    private String name;
    private int modeHashCat;
    private int counter = 0;

    /**
     * Constructor.
     */
    public HashTagDataType(String name, int modeHashCat) {
        this.name = name;
        this.modeHashCat = modeHashCat;
    }

    public HashTagDataType(String name) {
        this(name, Integer.MIN_VALUE);
    }

    /**
     * Increments the hashtag counter.
     */
    public void incrementCounter() {
        counter++;
    }

    /**
     * Getter.
     */
    public String getName() {
        return name;
    }

    public int getModeHashCat() {
        return modeHashCat;
    }

    public int getCounter() {
        return counter;
    }

}
