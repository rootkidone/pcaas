package Framework.hashtag;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 
 * <p/>
 * Reference:
 * - http://www.smeegesec.com/2013/11/hashtag-password-hash-identification.html
 */
public class HashTagManager {
    

    /**
     * Represents a manager to handle the different hashtags.
     */
    private Set<HashTagDataType> hashTagDataTypes;

    /**
     * Constructor.
     */
    public HashTagManager() {
        hashTagDataTypes = new HashSet<HashTagDataType>();
    }

    /**
     * Identify a hash with the help of "HashTag.py".
     *
     * @param hash
     * @return
     */
    public List<HashTagDataType> getHashTag(String hash) throws IOException, InterruptedException, IllegalAccessException {
        File hashTagFile = new File("/home/rootkid/Desktop/PCaaS_Framework_src/Framework/tools/HashTag.py");

        String[] command = {"python", hashTagFile.getPath(), "-sh", hash};
        ProcessBuilder processBuilder = new ProcessBuilder(command);

        Process process = null;
        process = processBuilder.start();

        InputStream inputStream = process.getInputStream();
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        String line = null;
        List<HashTagDataType> hashTagList = new ArrayList<HashTagDataType>();


        while ((line = bufferedReader.readLine()) != null) {
            HashTagDataType hashTagDataType = processHashTag(line);
            if (hashTagDataType != null) {
                hashTagDataTypes.add(hashTagDataType);
                hashTagDataType.incrementCounter();
                hashTagList.add(hashTagDataType);
            }
        }


        int exitValue = Integer.MIN_VALUE;
        exitValue = process.waitFor();

        if (exitValue == 0) {
            return hashTagList;
        } else {
            throw new InterruptedException(this.getClass().getSimpleName() + ": Error with exit code by ProcessBuilder.");
        }
    }

    /**
     * Analyze the output of "HashTag.py" and creating HashTagDataType objects.
     *
     * @param line
     * @return HashTagDataType
     */
    private HashTagDataType processHashTag(String line) {
        String name;
        HashTagDataType hashTagDataType = null;

        // Syntax: [*] Oracle 7-10g, DES(Oracle) - Hashcat Mode 3100
        if (line.contains("[*]")) {
            line = line.substring(3);
        } else {
            return null;
        }

        // Syntax: Oracle 7-10g, DES(Oracle) - Hashcat Mode 3100
        if (line.contains("Hashcat Mode")) {
            // Oracle 7-10g, DES(Oracle)
            name = line.split(" - ")[0].trim();

            // Hashcat Mode 3100
            int modeHashCat = Integer.valueOf(line.split(" - ")[1].trim().split(" ")[2]);

            hashTagDataType = getHashTagEntry(name);
            if (hashTagDataType == null) {
                hashTagDataType = new HashTagDataType(name, modeHashCat);
            }
        } else {
            // Syntax: MySQL, MySQL323
            name = line.trim();

            hashTagDataType = getHashTagEntry(name);
            if (hashTagDataType == null) {
                hashTagDataType = new HashTagDataType(name);
            }
        }

        return hashTagDataType;
    }

    /**
     * Getter.
     */
    private HashTagDataType getHashTagEntry(String name) {
        for (HashTagDataType hashTagDataType : hashTagDataTypes) {
            if (hashTagDataType.getName().equals(name)) {
                return hashTagDataType;
            }
        }
        return null;
    }

    public Set<HashTagDataType> getHashTagDataTypes() {
        return hashTagDataTypes;
    }
}
