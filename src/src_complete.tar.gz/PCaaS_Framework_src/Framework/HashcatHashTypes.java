/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Framework;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rootkid
 */
public class HashcatHashTypes {
    
    private Properties prop = new Properties();
    private Map<String,String> keyValueMap = new HashMap<String,String>();
    private InputStream input = null;
    
    
    public HashcatHashTypes(){
        loadHashTypesToMap();
    }
    
    public Map<String,String> getHashTypes(){return keyValueMap;}
    
    public void loadHashTypesToMap() {
        try{
            //lösung für pfad notwendig
            input = new FileInputStream("/home/rootkid/Desktop/PCaaS_Framework_src/properties.config");
            prop.load(input);
            //
            Enumeration enumeration = prop.keys();
            while(enumeration.hasMoreElements()){
                String key = (String) enumeration.nextElement();
                keyValueMap.put(key, prop.getProperty(key));
            }
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(HashcatHashTypes.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(HashcatHashTypes.class.getName()).log(Level.SEVERE, null, ex);
        }        finally{
            if(input != null){
                try{
                    input.close();
                }
                catch(IOException e){
                    e.printStackTrace();
                }
            }
        }
    }
    
}
