/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Framework;

/**
 *
 * @author rootkid
 */
public class FrameProcessIdentifierObject {
     private Integer _processID;
    private String _instance;
    
    
    public FrameProcessIdentifierObject(Integer processID, String p){
        this._processID = processID;
        this._instance = p;
    }
    
    public Integer getProcessID(){return _processID;}
    public String getProcessInstance(){return _instance;}
    
    public boolean equals(FrameProcessIdentifierObject other){
        if(this.getProcessID().equals(other.getProcessID()) &&
                this.getProcessInstance().equals(other.getProcessInstance())){
            return true;
        }
        
        return false;
    }
    public String toString(){
        return _processID + ":" + _instance;
    }
}
