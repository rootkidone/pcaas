package Framework.algorithm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

/**
 * 
 * <p/>
 * Reference:
 * - http://man7.org/linux/man-pages/man3/passwd.crypt.3.html
 */
public class PasswdAlgorithmManager {

    /**
     * List of all known algorithms.
     */
    private static Set<PasswdAlgorithmDataType> algorithmList;
    // Path to the config file which include the algorithms for Java Message Digest.
    private File configFile = new File("/home/rootkid/Desktop/PCaaS_Framework_src/Framework/config/algorithm.conf");

    /**
     * Constructor.
     */
    public PasswdAlgorithmManager() throws IOException {
        algorithmList = readConfigFile(configFile);
    }

    /**
     * Loading the config file.
     *
     * @return List&lt;PasswdAlgorithmDataType&gt;
     */
    private Set<PasswdAlgorithmDataType> readConfigFile(File configFile) throws IOException {
        int lineCount = 0;
        BufferedReader bufferedReader = null;

        bufferedReader = new BufferedReader(new FileReader(configFile));

        Set<PasswdAlgorithmDataType> algorithm = new HashSet<PasswdAlgorithmDataType>();
        String readLine;
        while ((readLine = bufferedReader.readLine()) != null) {
            lineCount++;

            // comment
            if (readLine.charAt(0) == '#') {
                continue;
            }

            String[] tokens = readLine.trim().split(":");
            // tag:name
            if (tokens.length == 2) {
                algorithm.add(new PasswdAlgorithmDataType(tokens[0], tokens[1]));
                // unknown line format
            } else {
                throw new IllegalArgumentException(this.getClass().getSimpleName() + ": Line " + lineCount + " unknown line format | " + readLine + " |");
            }
        }

        bufferedReader.close();


        return algorithm;
    }

    /**
     * Checks if the algorithmList exists.
     *
     * @param otherAlgorithmTag
     * @return true: if the algorithmList tag exists
     * false: if the algorithmList tag doesn't exist
     */
    public boolean algortihmExist(String otherAlgorithmTag) {
        for (PasswdAlgorithmDataType passwdAlgorithmDataType : algorithmList) {
            if (passwdAlgorithmDataType.getTag().equals(otherAlgorithmTag)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adds a algorithmList to the known list of algorithms.
     *
     * @param newAlgorithm
     */
    public void addAlgorithm(PasswdAlgorithmDataType newAlgorithm) {
        algorithmList.add(newAlgorithm);
    }

    /**
     * Getter.
     */
    public Set<PasswdAlgorithmDataType> getAlgorithmList() {
        return algorithmList;
    }

    public PasswdAlgorithmDataType getAlgorithmByTag(String value) {
        for (PasswdAlgorithmDataType v : algorithmList)
            if (v.getTag().equalsIgnoreCase(value)) return v;
        throw new IllegalArgumentException();
    }

    public PasswdAlgorithmDataType getAlgorithmByLabel(String value) {
        for (PasswdAlgorithmDataType v : algorithmList)
            if (v.getLabel().equalsIgnoreCase(value)) return v;
        throw new IllegalArgumentException();
    }

}
