package Framework.algorithm;

/**
 * 
 * <p/>
 * Reference:
 * - http://man7.org/linux/man-pages/man3/passwd.crypt.3.html
 */
public class PasswdAlgorithmDataType {

    /**
     * Represents the known algorithms.
     * The algorithms which can be made with the Java Message Digest lib also have an label.
     */
    private String tag;
    private String label;
    private int counter = 0;

    /**
     * Constructor.
     */
    public PasswdAlgorithmDataType(String tag, String label) {
        this.tag = tag;
        this.label = label;
    }

    public PasswdAlgorithmDataType(String tag) {
        this(tag, null);
    }

    /**
     * Increments the algorithm counter.
     */
    public void incrementCounter() {
        counter++;
    }

    /**
     * Getter.
     */
    public String getTag() {
        return tag;
    }

    public String getLabel() {
        return label;
    }

    public int getCounter() {
        return counter;
    }

}
